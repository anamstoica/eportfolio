# Literature Retrieval MaS – FINAL

# Based on the group plan: Multi-Agent System based on BDI
# and using Python and the official Crossref REST API (via habanero).

import json
import re
import time
import random
from habanero import Crossref


# Step 1 - Input Acquisition
# Using habanero for handling URL construction, API rest limits and automatic JSON parsing
# max_results is an optional argument, but I chose to limit 5 results to reduce load on Crossref servers and avoid spamming.

def SearchAgent(search_term, max_results=5):

    cr = Crossref()

    # An optional filter for year can be added here using habanero's filter
    # filters = {"from-pub-date": f"{from_year}-01-01"}

    results = cr.works(query=search_term, limit=max_results)

    items = results.get("message", {}).get("items", [])
    print(f"Found {len(items)} articles")

    # Return the raw items for the extraction agent
    return items


# Step 2 - Extraction, Validation and Transformation
# Checks and logs missing fields and transforms data by removing duplicate DOIs and normalizing author names

def ExtractionAgent(data):

    clean_items = []

    # Keeping DOI, title, and year because they are critical when referencing.
    # Authors formatted only for consistency and abstracts preserved if present
    
    for i in data:
        title = (i.get("title") or [""])[0]
        doi = i.get("DOI", "")
        year = (i.get("issued", {}).get("date-parts") or [[None]])[0][0]

        if title and doi:
        
            authors = [" ".join(filter(None, [a.get("given"), a.get("family")])) 
            for a in i.get("author", [])]

            clean_items.append({
                "title": title.strip(),
                "doi": doi,
                "year": str(year) if year else "Unknown",
                "author": authors,
                "abstract": i.get("abstract", "N/A"),
                "url": f"https://doi.org/{doi}"
            })
    print(f"Kept {len(clean_items)} valid records")

    print("Validating data in progress...")
    valid = []

    for d in clean_items:
        incomplete = False
        for field in ["title", "doi", "year"]:
            if not d.get(field) or d[field] == "Unknown":
                print(f"Missing {field} in {d.get('url')}")
                incomplete = True
        if not incomplete:
            valid.append(d)

    if not valid:
        print("No complete records found")
    else:
        print(f"{len(valid)} valid records remain.")

    print("Removing duplicates in progress...")
    uniques = set()
    deduplicated = []
    for d in valid:
        if d["doi"] not in uniques:
            uniques.add(d["doi"])
            d["author"] = ", ".join([a.title() for a in d["author"]]) if d["author"] else "Unknown"
            deduplicated.append(d)
    print(f"{len(deduplicated)} unique records remain.")
    return deduplicated


# Step 3 - Storage
# Saving metadata in JSON format, chosen to preserve structure and handle Unicode characters safely

def StorageAgent(data, filename="cleanedresults.json"):
    
    print("Saving results to file...")
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    print(f"File saved as {filename}.")


# Sequential Workflow Setup

class OrchestratorAgent:

    def __init__(self, search_agent, extraction_agent, storage_agent):
        self.search_agent = search_agent
        self.extraction_agent = extraction_agent
        self.storage_agent = storage_agent

    def run(self, query, filename):
        start_time = time.time()

        data = self.search_agent(query)
        if not data:
            print("No data retrieved. Ending session.")
            return

        extracted = self.extraction_agent(data)
        self.storage_agent(extracted, filename=filename)

        elapsed = time.time() - start_time
        print(f"Process completed in {elapsed:.2f} seconds.\n")

        return extracted


# Execution

orchestrator = OrchestratorAgent(
    search_agent=SearchAgent,
    extraction_agent=ExtractionAgent,
    storage_agent=StorageAgent
)

user_query = input("Enter your research query: ")
orchestrator.run(user_query, filename="cleanedresults.json")
