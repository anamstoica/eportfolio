import os
import json
import pytest
from main import OrchestratorAgent, SearchAgent, ExtractionAgent, StorageAgent

 # I was with hit with network timeouts when using the real API, so I went with a fake agent for the Orchestrator Agent to use

def fake_search_agent(query, max_results=5):
    
    return [
        {
            "title": ["Sample Paper 1"],
            "DOI": "10.1234/sample1",
            "issued": {"date-parts": [[2020]]},
            "author": [{"given": "Bart", "family": "Simpson"}],
            "abstract": "This is a sample abstract."
        },
        {
            "title": ["Sample Paper 2"],
            "DOI": "10.1234/sample2",
            "issued": {"date-parts": [[2021]]},
            "author": [{"given": "Bob", "family": "Burger"}],
            "abstract": "Another abstract."
        }
    ] 

def test_workflow_creates_file(tmp_path):
    output_file = tmp_path / "results.json"

    orchestrator = OrchestratorAgent(
        search_agent=fake_search_agent,
        extraction_agent=ExtractionAgent,
        storage_agent=StorageAgent
    )

    orchestrator.run(query="cheese", filename=output_file)

    assert os.path.exists(output_file), "Output file was not created."

    with open(output_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    assert len(data) == 2, "Expected 2 valid records in the output."

    sample = data[0]
    assert "title" in sample, "Missing title field."
    assert "doi" in sample, "Missing doi field."
    assert "url" in sample, "Missing url field."
    assert sample["author"] == "Bart Simpson", "Author formatting incorrect."
