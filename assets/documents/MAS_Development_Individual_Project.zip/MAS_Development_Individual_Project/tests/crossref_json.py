import json
from habanero import Crossref

cr = Crossref()
search_term = "machine learning"
results = cr.works(query=search_term, limit=5)

# Save the full JSON response to a file
with open("crossref_results.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=4)


print ("Successfully ran!")