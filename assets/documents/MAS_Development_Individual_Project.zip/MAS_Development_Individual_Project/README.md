# Multi-Agent Literature Retrieval (BDI-inspired)

## What this is
A simple Python implementation of a Multi-Agent System inspired by BDI (Belief-Desire-Intention) principles.  
The system automates academic literature retrieval from Crossref, processes and validates metadata, and stores results in JSON format. Designed for Unit 6 deliverable & practical assignment.

## Requirements
- Python 3.9+
- Packages: `pip install habanero pytest`

## Files
- crossref_json - A short script that shows what the output of the Search Agent is.
- main.py – Main system implementation.
- test_main.py – Unit test file using pytest.
- cleanedresults.json – Example output file.
- README.md – This documentation file.

## Run
- Example run: `python main.py`
- Unit tests: `pytest -q -s`. The project’s structure and imports rely on running the script as a Python module, which is why some systems may need to use `python -m pytest -q -s`.

## Workflow
1. **SearchAgent**: Queries Crossref API for articles matching a search term (default 5 results to avoid overloading API).  
2. **ExtractionAgent**: Validates critical fields (DOI, title, year) and filters invalid DOIs.   
3. **StorageAgent**: Saves results in structured JSON for universal compatibility.  
4. **OrchestratorAgent**: Logs missing critical fields to catch incomplete metadata.  

## Design decisions
- **Crossref API & habanero**: Chosen for stable metadata, automatic JSON parsing, and built-in rate-limit handling.  
- **Result limit**: Keeps API requests polite and avoids excessive data.  
- **Metadata-centered approach**: DOI, title, and year prioritized to ensure valid references.  
- **Data cleaning**: Removes incomplete records, formats author names, and normalizes fields for consistency.
- **Storage**: JSON format chosen for structure, Unicode support, and universality.  

## Testing & Evidence
- Tests are in the `tests`folder.  
- Saved demo output in `cleanedresults.json` and included screenshots of terminal running as evidence.  

## Academic sources
- Report and justification recorded in group Final Report (Unit 6). See project references in final report.
- Additional justifications for my personal choices of procedure can be found in the transcript file.
